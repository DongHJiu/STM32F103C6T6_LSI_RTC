#include "stm32f10x.h"                  // Device header
#include "RTC.h"
#include "Delay.h"
#include "OLED.h"

_calendar calendar;
  
/**
    * @brief  中断优先级配置
    * @param  无
    * @retval 无  
    */	
//void RTC_NVIC_Cpnfig(){
//	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
//	NVIC_InitTypeDef NVIC_InitStructure;
//	
//	NVIC_InitStructure.NVIC_IRQChannel=RTC_IRQn;
//	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
//	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=2;
//	NVIC_InitStructure.NVIC_IRQChannelSubPriority=3;
//	NVIC_Init(&NVIC_InitStructure);
//}	

/**
  * @brief  获取计数器的值
  * @param  无
  * @retval 无  
  */
void RTC_Get(){
	u32 temp_Get;
	temp_Get=RTC_GetCounter();              //获取计数器的值
	calendar.hour=temp_Get/3600;            //将计数器的值转换后放进calendar.hour中
	calendar.min=(temp_Get%3600)/60;          //将计数器的值转换后放进calendar.min中
	calendar.sec=temp_Get%60;               //将计数器的值转换后放进calendar.sec中
	
}

/**
  * @brief  RTC时钟初始化
  * @param  无
  * @retval 返回值1则配置失败，返回值为0则配置成功  
  */
u8 RTC_Init(){
	u8 temp=0;
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR|RCC_APB1Periph_BKP,ENABLE);   //使能电源时钟和后备域时钟
	PWR_BackupAccessCmd(ENABLE);                                            //开启RTC后备寄存器写访问
	
	if(BKP_ReadBackupRegister(BKP_DR1)!=0xA0A0){      //读取RTC后备寄存器的值(这里读取DR1的值是否等于0xA0A0)
		BKP_DeInit();                //复位备份区域
		RCC_LSEConfig(RCC_LSE_ON);                    //开启外部低速振荡器
		while(RCC_GetFlagStatus(RCC_FLAG_LSERDY)==RESET&&temp<250){               //判断LSE外部低速振荡器是否准备就绪(如准备就绪返回值为RESET)
			temp++;
			Delay_ms(10);
		}
		if(temp>=250){
			return 1;                                              //如果等待判断的时间大于2500ms，则返回值为1
		}
		RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE);                                 //设置RTC时钟，这里设置为外部低速时钟(32.768KHZ)
		RCC_RTCCLKCmd(ENABLE);                                                  //使能RTC时钟
		RTC_WaitForLastTask();                             //等待RTC寄存器写完成
		RTC_WaitForSynchro();                              //等待RTC和内部时钟相同步
		 RTC_ITConfig(RTC_IT_SEC,DISABLE);                       //配置秒中断
		RTC_WaitForLastTask();
		RTC_EnterConfigMode();  //开启RTC寄存器配置模式
		RTC_SetPrescaler(32767);  //对RTC寄存器进行分频
		RTC_WaitForLastTask();
		RTC_SetCounter(0x5460);                     //设置计数器的起始值(这里的输入值是16进制32位的)(如要6点(6个小时)开始计数,起始值=(1(HZ)*6(时)*60(分)*60(秒),这里的1HZ是上面分频后所得的值))
		RTC_ExitConfigMode();   //退出RTC配置模式
		
		BKP_WriteBackupRegister(BKP_DR1,0xA0A0);      //写入RTC后备寄存器的值(这里将0xA0A0写入DR1寄存器)
		
	}
	else{
		RTC_WaitForSynchro();
		RTC_ITConfig(RTC_IT_SEC,ENABLE);
		RTC_WaitForLastTask();
	}
		//RTC_NVIC_Cpnfig();
	  RTC_Get();
		
		return 0;
}	

	

