#ifndef __RTC_H
#define __RTC_H	    

typedef struct{
	u8 hour;
	u8 min;
	u8 sec;
}_calendar;

void RTC_Get(void);
u8 RTC_Init(void);

extern _calendar calendar;

#endif
