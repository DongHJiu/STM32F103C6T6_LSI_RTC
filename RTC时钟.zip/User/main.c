#include "stm32f10x.h"                  // Device header
#include "RTC.h"
#include "OLED.h"


int main(void){	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
 	GPIO_Init(GPIOB, &GPIO_InitStructure);
	GPIO_WriteBit(GPIOB,GPIO_Pin_7,Bit_RESET);	
	RTC_Init();
	OLED_Init();
	OLED_ShowChar(1,3,':');
	OLED_ShowChar(1,6,':');
	while(1){
		
	}	
}
